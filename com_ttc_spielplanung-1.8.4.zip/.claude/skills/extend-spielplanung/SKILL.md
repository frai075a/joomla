---
name: extend-spielplanung
description: Use when adding a new DB column/field, a new admin-side Mmb/Kategorien grid field, or a new frontend Spielplan behavior to com_ttc_spielplanung. Covers the schema-migration checklist and the naming/language conventions specific to this component.
---

# Extending com_ttc_spielplanung

This is a Joomla 5 component with two independent MVC stacks (`administrator/`, `site/`) sharing one DB schema. Read `CLAUDE.md` at the repo root first for the domain model (`#__ttc_mmb`, `#__ttc_relevante_kategorien`, `#__ttc_spielplanung`, and the read-only `#__ttc_spielplan` owned by `com_spielplan`).

## Adding a new DB column

Do all four steps together — they're never done in isolation here:

1. Bump `<version>` in `com_ttc_spielplanung.xml` (patch bump for a single column).
2. Add the column to `administrator/sql/install.mysql.utf8.sql` (so fresh installs get it).
3. Add a new file `administrator/sql/updates/<new-version>.sql` with the `ALTER TABLE` (so upgrades get it). One file per version; never edit an already-released update file. `sql/updates/` is currently empty (only `index.html`) — the schema was consolidated into `install.mysql.utf8.sql` and old update files were removed, so the next file starts a fresh sequence rather than continuing old numbering.
4. Update the `Model`'s `getListQuery()`/`select()` to expose the column, and the owning **Model**'s save method (e.g. `MmbModel::saveRows()`, `KategorienModel::saveSelection()`) to read/persist it from the data the Controller forwards. Controllers in this component never write to the DB themselves — they decode the request and call the Model; keep new fields the same way.

Check `git status`/`git diff` on the `sql/updates/*.sql` file before assuming it's active — it has been intentionally commented out before in this repo while a migration was deferred; don't silently re-enable it.

If the new column must also survive sites that went through a previously-broken upgrade (i.e. `sql/updates` alone isn't trustworthy for them), add the same idempotent `getTableColumns()`-check-and-`ALTER TABLE` pattern to `script.php`'s `postflight()`, next to the existing `is_captain` check — don't swallow its `execute()` failure, an unusable schema should fail the install/update.

## Adding a field to the Mmb admin grid (`administrator/tmpl/mmb/default.php`)

This view is **not** a JForm edit dialog — it's one big inline-edit `<table>` inside a single `<form>`, submitting every row at once as `mmb[<user_id>][field_name]`. To add a field:

- Add a `<th>` + per-row `<td>` in `administrator/tmpl/mmb/default.php`, named `mmb[<?php echo (int) $item->id; ?>][your_field]`.
- `MmbController::save()` just forwards the whole `mmb` array unchanged (`$this->input->post->get('mmb', array(), 'array')`) to `MmbModel::saveRows()` — read `$itemData['your_field']` there, inside its existing per-`user_id` loop.
- If the field has cross-row constraints (like `is_captain`'s "one per category" rule), enforce them **server-side in `MmbModel::saveRows()`**, not just in the client-side JS — the JS in this file is UX-only convenience, never authoritative.
- Add the column to `MmbModel::getListQuery()`'s `->select(...)` so the template can read `$item->your_field`.

## Adding a shared filter to the frontend dialogs (`spielplan`, `saisonplanung`, `saisonplanungmf`)

All three frontend templates share the same GET-filter mechanics — a new filter always touches all three stacks together, never just one dialog:

1. `SpielplanungRepository::createUserGamesQuery($userId, $onlyFuture = false, ...)` — add the new parameter here and apply it as a `->where(...)` clause. This is the single place the filter actually takes effect.
2. Each of `SpielplanModel::getGames()`, `SaisonplanungModel::getGames()` (site), and `SaisonplanungmfModel::getGames()` — add the same parameter and forward it to `createUserGamesQuery()`.
3. Each of `Spielplan/HtmlView.php`, `Saisonplanung/HtmlView.php`, `Saisonplanungmf/HtmlView.php` — read the GET value with `Factory::getApplication()->input->getBool('your_filter', false)` into a new public property, and pass it into `getGames(...)`. Unlike `only_future`, don't bother with an `_submitted` guard unless the filter needs a default of `true` on first visit — unchecked-by-default filters don't need one.
4. Each of the three `site/tmpl/*/default.php` templates — add a `<div class="form-check">` checkbox inside the existing `.com-ttc-spielplanung-filter-box` wrapper, `onchange="this.form.submit()"`, checked from the view's public property. In `saisonplanungmf/default.php` specifically, also add a matching `<input type="hidden">` in the second (save) `<form>` and append the value to `SaisonplanungmfController::saveGame()`'s `$returnUrl`, the same way `only_future` is carried through — otherwise the filter resets to unchecked after every save.
5. Add the new regression test fixture data and a `test(...)` case in `tests/regression.php` (see below) — don't rely on manual browser testing alone, there's no Joomla install in this environment to test against.

## Language keys

- Add new keys as `COM_TTC_SPIELPLANUNG_<PURPOSE>` in both `administrator/languages/en-GB/com_ttc_spielplanung.ini` and, if the frontend needs the same string, the separate `site/language/en-GB/com_ttc_spielplanung.ini` (they are not shared — duplicate deliberately).
- Prefer a new component-specific key over reusing a Joomla core key (`JGLOBAL_*`) even when the core key's English text matches, since the German wording here has already diverged from Joomla defaults on request (e.g. category → "Mannschaftszuordnung", name → "Spieler").
- The `en-GB` files contain German text — this is intentional, there is no `de-DE` file to keep in sync.

## Frontend mail notifications (`site/src/Service/CaptainNotificationService.php`)

Captain notifications on availability change use `Factory::getMailer()` inline inside this service (no generic mail-helper class exists). `SpielplanModel::saveAndNotify()` commits the save first, then calls the service and returns its warnings; controllers display them with `enqueueMessage(..., 'warning')`. Keep this pattern for any new notification: wrap `Send()` in try/catch inside the service, return warning strings rather than throwing, and never let a mail failure roll back the DB transaction or block the user-facing success message.

## Regression tests (`tests/regression.php`)

Run with `php -d extension=pdo_sqlite tests/regression.php` after any Model/Controller change — it's a standalone script (no PHPUnit) that doubles the Joomla classes it needs and `require`s the real component source against an in-memory SQLite DB, so it catches query/logic bugs without a Joomla install. If you add a new Model, Controller, or View, add its `require` near the top of the script's `namespace {}` block and write a case for its new behavior — don't let it silently stay uncovered.
