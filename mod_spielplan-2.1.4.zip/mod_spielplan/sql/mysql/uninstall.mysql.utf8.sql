-- spielplan must not be dropped
;