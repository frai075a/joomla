DROP TABLE IF EXISTS `#__ttc_hallenschliesszeiten`;
