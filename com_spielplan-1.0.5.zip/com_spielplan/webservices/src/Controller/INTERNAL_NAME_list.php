<?php
/**
 * @version    CVS: 1.0.4
 * @package    Com_Spielplan
 * @author     Thorsten Austen <thorsten.austen@gmail.com>
 * @copyright  2024 Thorsten Austen
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
namespace Ttc\Component\Spielplan\Api\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\ApiController;

/**
 * The XXX_UCFIRST_INTERNAL_NAME_FORCE_LIST_XXX controller
 *
 * @since  1.0.4
 */
class XXX_UCFIRST_INTERNAL_NAME_FORCE_LIST_XXXController extends ApiController 
{
	/**
	 * The content type of the item.
	 *
	 * @var    string
	 * @since  1.0.4
	 */
	protected $contentType = 'XXX_INTERNAL_NAME_FORCE_LIST_XXX';

	/**
	 * The default view for the display method.
	 *
	 * @var    string
	 * @since  1.0.4
	 */
	protected $default_view = 'XXX_INTERNAL_NAME_FORCE_LIST_XXX';
}