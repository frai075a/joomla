DROP TABLE IF EXISTS `#__ttc_spielplan`;
